연구회 (Spring boot)
======

  
## Eclipse Java11 적용하기.
1. Download JDK11 - http://jdk.java.net/11/ 
2. Eclipse update - http://download.eclipse.org/eclipse/updates/4.9-P-builds
3. Gradle 5 버전 - https://gradle.org/install/ 
4. Eclipse 및 workspace 설정 - jre/jdk 설정변경 -> jdk11 로 변경. 
5. Post Man - https://www.getpostman.com/downloads/


- [EffectiveJAVA 원서](https://github.com/GianfrancoMS/Books/blob/master/Java/Effective%20Java%20(3rd%20Edition).pdf)
- [.md 파일만들기](https://heropy.blog/2017/09/30/markdown/)
