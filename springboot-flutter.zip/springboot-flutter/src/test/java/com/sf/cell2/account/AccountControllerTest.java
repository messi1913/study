package com.sf.cell2.account;

import com.sf.cell2.common.BaseControllerTest;
import com.sf.cell2.common.MethodDescription;
import org.junit.Test;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpHeaders;

import static org.springframework.restdocs.headers.HeaderDocumentation.*;
import static org.springframework.restdocs.hypermedia.HypermediaDocumentation.linkWithRel;
import static org.springframework.restdocs.hypermedia.HypermediaDocumentation.links;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class AccountControllerTest extends BaseControllerTest {

    @Test
    @MethodDescription("사용자 한건을 조회한다. ")
    public void getUser() throws Exception {
        mockMvc.perform(get("/accounts/{id}", 2)
                    .accept(MediaTypes.HAL_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("userName").exists())
                .andExpect(jsonPath("email").exists())
                .andExpect(jsonPath("mobileNumber").exists())
                .andExpect(jsonPath("_links.self").exists())
                .andExpect(jsonPath("_links.profile").exists())
                .andDo(document("get-account",
                        links(
                                linkWithRel("self").description("Link to self"),
                                linkWithRel("profile").description("Link to profile"),
                                linkWithRel("update-account").description("Link to update information of user")
                        ),
                        requestHeaders(
                                headerWithName(HttpHeaders.ACCEPT).description("Accept header")
                        ),
                        responseHeaders(
                                headerWithName(HttpHeaders.CONTENT_TYPE).description("Content Type")
                        ),
                        responseFields(
                                fieldWithPath("userName").type(String.class).description("Name of account"),
                                fieldWithPath("email").type(String.class).description("Name of account"),
                                fieldWithPath("mobileNumber").type(String.class).description("Name of account"),
                                fieldWithPath("_links.self.href").description("Link to self"),
                                fieldWithPath("_links.update-account.href").description("Link to update user"),
                                fieldWithPath("_links.profile.href").description("Link to get account")
                        )
                ));
    }

}