package com.sf.cell2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cell2Application {

    public static void main(String[] args) {
        SpringApplication.run(Cell2Application.class, args);
    }

}
