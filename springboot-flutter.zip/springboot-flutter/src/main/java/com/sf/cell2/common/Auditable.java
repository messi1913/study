package com.sf.cell2.common;

public interface Auditable {

    Audit getAudit();
    void setAudit(Audit audit);
}
