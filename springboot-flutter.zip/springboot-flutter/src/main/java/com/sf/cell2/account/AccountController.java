package com.sf.cell2.account;

import com.sf.cell2.common.MethodDescription;
import com.sf.cell2.exception.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

@RestController
@RequestMapping(value = "/accounts",  produces = MediaTypes.HAL_JSON_UTF8_VALUE)
@RequiredArgsConstructor
public class AccountController {

    private final AccountService service;
    private final AccountValidator validator;


    @GetMapping("/{id}")
    @MethodDescription("사용자 한건 조회")
    public ResponseEntity getUser(@PathVariable Long id) {
        try {
            AccountDTO accountDTO = service.getUser(id);
            var accountResource = new AccountResource(accountDTO);
            accountResource.add(new Link("/docs/account.html#resources-account-get").withRel("profile"));
            accountResource.add(linkTo(AccountController.class).withRel("update-account"));
            accountResource.add(linkTo(AccountController.class).slash(id).withSelfRel());
            return ResponseEntity.ok(accountResource);
        } catch (NotFoundException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    @MethodDescription("사용자 리스트 조회")
    public ResponseEntity getUsers(@RequestParam String name) {
        try {
            List<AccountDTO> accountDTOList = service.getUsers(name);
            return ResponseEntity.ok(accountDTOList);
        } catch (NotFoundException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping
    @MethodDescription("사용자 생성")
    public ResponseEntity createUser(@RequestBody Account account, Errors errors) {
        if(errors.hasErrors())
            return badRequest(errors);

        AccountDTO accountDTO = service.createUser(account);
        return ResponseEntity.ok(accountDTO);
    }

    @PutMapping
    @MethodDescription("사용자 수정")
    public ResponseEntity saveUser(@RequestBody Account account, Errors errors) {
        if(errors.hasErrors())
            return badRequest(errors);

        validator.validateSave(account, errors);

        if(errors.hasErrors())
            return badRequest(errors);

        try {
            AccountDTO accountDTO = service.saveUser(account);
            return ResponseEntity.ok(accountDTO);
        } catch (NotFoundException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }

    }

    @DeleteMapping("/{id}")
    @MethodDescription("사용자 삭제")
    public ResponseEntity deleteUser(@PathVariable Long id) {
        if(!service.existsUser(id))
            return ResponseEntity.badRequest().body("This id ["+id+"] of Account does not exist!! ");
        service.deleteUser(id);
        return ResponseEntity.ok("Delete ["+id+"] account successfully");
    }

    @MethodDescription("Bad request 처리 ")
    private ResponseEntity badRequest(Errors errors) {
        //return ResponseEntity.badRequest().body(new ErrorResource(errors));
        return ResponseEntity.badRequest().body(errors.toString());
    }

}
