package com.sf.cell2.account;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

public class AccountResource  extends Resource<AccountDTO> {

    public AccountResource(AccountDTO account, Link... links) {
        super(account, links);
//        add(linkTo(AccountController.class).slash(account.getEmail()).withSelfRel());
    }

}
