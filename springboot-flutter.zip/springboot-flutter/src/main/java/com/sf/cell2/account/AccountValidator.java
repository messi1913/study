package com.sf.cell2.account;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

@Component
@RequiredArgsConstructor
public class AccountValidator {

    private final AccountService service;

    public void validateSave(Account account, Errors errors) {
        if(!service.existsUser(account)) {
            errors.rejectValue("Not found", "Can not find this account!!");
        }
    }


}