package com.sf.cell2.account;


import org.hamcrest.Matchers;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Set;
import java.util.regex.Matcher;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AccountServiceTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Autowired
    AccountService service;
    @Autowired
    AccountRepository repository;
    @Autowired
    PasswordEncoder passwordEncoder;

    @Test
    public void findByUsername() {
        //Given
        String email = "messi1913@gmail.com";
        String password = "rlatkdap1";
        Account account = Account.builder()
                .email(email)
                .password(password)
                .mobileNumber("010-9989-1913")
                .userName("상메시")
                .roles(Set.of(AccountRole.ADMIN, AccountRole.GENERAL))
                .build();

        this.service.createUser(account);

        //When
        UserDetailsService userDetailsService = service;
        UserDetails userDetails = userDetailsService.loadUserByUsername(email);

        //Then
        assertThat(passwordEncoder.matches(password, userDetails.getPassword())).isTrue();

    }

    @Test
    public void failedFindByUsername() {
        String username = "asdjlkasdfjlkasdfjlkasdjf";
        //Expected
        expectedException.expect(UsernameNotFoundException.class);
        expectedException.expectMessage(Matchers.containsString(username));

        //When
        this.service.loadUserByUsername(username);

    }

}