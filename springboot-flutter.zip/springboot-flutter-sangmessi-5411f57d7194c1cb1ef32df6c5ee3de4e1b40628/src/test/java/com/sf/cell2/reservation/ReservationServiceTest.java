package com.sf.cell2.reservation;

import com.sf.cell2.common.BaseControllerTest;
import com.sf.cell2.common.MethodDescription;
import com.sf.cell2.exception.NotFoundException;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;


public class ReservationServiceTest extends BaseControllerTest {

    @Autowired
    ReservationService service;

    @Autowired
    ReservationRepository repository;

    @Test
    @MethodDescription("예약 생성하는 API")
    public void createReservation() {
        ReservationDTO reservation = ReservationDTO.builder()
                .bookedOn(LocalDateTime.of(2019, 6, 11, 18, 30))
                .reservationStatus(ReservationStatus.PRE_BOOKING)
                .reservationType(ReservationType.FOOD)
                .name("내기빵 회식")
                .description("바르샤 슈방")
                .numbers(10)
                .build();

        ReservationDTO reservationDTO = this.service.createReservation(reservation);

        assertThat(reservationDTO.getId()).isNotNull();
        assertThat(reservationDTO.getBookedOn()).isNotNull();
        assertThat(reservationDTO.getName()).isNotNull();
        assertThat(reservationDTO.getNumbers()).isNotNull();
        assertThat(reservationDTO.getReservationStatus()).isNotNull();
    }

    @Test
    @MethodDescription("예약 수정 하는 API")
    public void modifyReservation() throws NotFoundException {
        List<Reservation> reservationList = repository.findAll();
        Reservation reservation = reservationList.get(0);

        int numbers = 9;
        String descriptions = "호수가 쏜다고 함";
        ReservationDTO reservationDTO = ReservationDTO.builder()
                .id(reservation.getId())
                .numbers(numbers)
                .description(descriptions)
                .build();

        ReservationDTO updateDTO = this.service.modifyReservation(reservationDTO);

        assertThat(updateDTO.getId()).isEqualTo(reservation.getId());
        assertThat(updateDTO.getNumbers()).isEqualTo(numbers);
        assertThat(updateDTO.getDescription()).isEqualTo(descriptions);
    }

    @Test
    @MethodDescription("예약 삭제 하는 API")
    public void cancelReservation() throws Exception {
        List<Reservation> reservationList = repository.findAll();
        Reservation reservation = reservationList.get(0);

        ReservationDTO reservationDTO = ReservationDTO.builder()
                .id(reservation.getId())
                .reservationStatus(ReservationStatus.CANCELED)
                .build();

        ReservationDTO updateDTO = this.service.modifyReservation(reservationDTO);

        assertThat(updateDTO.getId()).isEqualTo(reservation.getId());
        assertThat(updateDTO.getReservationStatus()).isEqualTo(ReservationStatus.CANCELED);

    }

    @Test
    public void getReservation() throws Exception {
        List<Reservation> reservationList = repository.findAll();
        Reservation reservation = reservationList.get(0);
        Long id = reservation.getId();

        ReservationDTO reservationDTO = this.service.retrieveReservation(id);

        assertThat(reservationDTO).isNotNull();
        assertThat(reservationDTO.getNumbers()).isNotNull();
    }

}