package com.sf.cell2.account;

public enum AccountRole {
    ADMIN, GENERAL, GUEST
}
