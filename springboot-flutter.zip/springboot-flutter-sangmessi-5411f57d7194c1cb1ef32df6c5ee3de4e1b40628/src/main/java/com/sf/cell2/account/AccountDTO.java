package com.sf.cell2.account;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor  @AllArgsConstructor
public class AccountDTO {
    private Long id;
    private String userName;
    private String email;
    private String mobileNumber;

}
