package com.sf.cell2.reservation;

public enum ReservationType {
    FOOD, DELIVERY, ACCOMODATION, VEHICLE
}
