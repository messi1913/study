package com.sf.cell2.reservation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sf.cell2.account.Account;
import com.sf.cell2.common.Audit;
import com.sf.cell2.common.AuditListener;
import com.sf.cell2.common.Auditable;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Data
@EqualsAndHashCode(of = "id")
@Builder
@NoArgsConstructor @AllArgsConstructor
@EntityListeners(AuditListener.class)
public class Reservation implements Auditable {

    @Id
    @GeneratedValue
    private Long id;

    @Column(nullable = false)
    @NotNull
    private LocalDateTime bookedOn;
    private String description;
    private String name;
    private int numbers;
    @Enumerated(EnumType.STRING)
    private ReservationStatus reservationStatus;
    @Enumerated(EnumType.ORDINAL)
    private ReservationType reservationType;

    private Integer deposit;
    private Integer totalFee;

    @ManyToOne
    private Account owner;

    @Embedded
    @JsonIgnore
    private Audit audit;

}
