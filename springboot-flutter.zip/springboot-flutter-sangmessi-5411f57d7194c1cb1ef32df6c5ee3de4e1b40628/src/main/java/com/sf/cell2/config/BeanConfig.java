package com.sf.cell2.config;

import com.sf.cell2.account.Account;
import com.sf.cell2.account.AccountRole;
import com.sf.cell2.account.AccountService;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class BeanConfig {

    @Bean
    public ModelMapper modelMapper(){
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());
        return modelMapper;
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

//    @Bean
//    public ApplicationRunner applicationRunner() {
//        return new ApplicationRunner() {
//            @Autowired
//            AccountService accountService;
//            @Override
//            public void run(ApplicationArguments args) throws Exception {
//                Account account = Account.builder()
//                        .email("messi1913@gmail.com")
//                        .userName("상메시")
//                        .password("rlatkdap1!")
//                        .mobileNumber("010-9989-1913")
//                        .roles(Set.of(AccountRole.ADMIN, AccountRole.GENERAL))
//                        .build();
//
//                this.accountService.saveUser(account);
//            }
//        };
//    }
}
