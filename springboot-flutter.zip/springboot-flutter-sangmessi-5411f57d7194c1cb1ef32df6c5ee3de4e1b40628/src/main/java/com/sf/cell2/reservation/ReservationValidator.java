package com.sf.cell2.reservation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import java.time.LocalDateTime;
import java.util.Objects;

@Component
public class ReservationValidator {

    public void validate(ReservationDTO reservationDTO, Errors errors) {
        LocalDateTime bookedOn =reservationDTO.getBookedOn();
        LocalDateTime now = LocalDateTime.now();

        if(now.isAfter(bookedOn))
            errors.rejectValue("Wrong Time", "Reservation time should be after now");


        Integer deposit = reservationDTO.getDeposit();
        Integer totalFee = reservationDTO.getTotalFee();

        if(!Objects.isNull(deposit) && !Objects.isNull(totalFee))
            if(deposit > totalFee)
                errors.rejectValue("wrongPrice", "Values to prices are wrong");

    }
}
