package com.sf.cell2.reservation;

import com.sf.cell2.common.MethodDescription;
import com.sf.cell2.exception.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ReservationService {

    private final ReservationRepository repository;
    private final ModelMapper modelMapper;


    @MethodDescription("예약 1건을 생성한다")
    public ReservationDTO createReservation(ReservationDTO reservationDTO) {
        Reservation reservation = modelMapper.map(reservationDTO, Reservation.class);
        Reservation savedReservation = this.repository.save(reservation);
        return modelMapper.map(savedReservation, ReservationDTO.class);
    }

    public ReservationDTO modifyReservation(ReservationDTO reservationDTO) throws NotFoundException {
        Optional<Reservation> reservationOptional = this.repository.findById(reservationDTO.getId());
        Reservation reservation = reservationOptional.orElseThrow(() -> new NotFoundException("There is no reservation to modify"));

        modelMapper.map(reservationDTO, reservation);

        Reservation savedReservation = this.repository.save(reservation);
        return modelMapper.map(savedReservation, ReservationDTO.class);
    }

    public ReservationDTO retrieveReservation(Long id) {
        Optional<Reservation> reservationOptional = this.repository.findById(id);
        if(reservationOptional.isEmpty())
            return null;
        Reservation reservation = reservationOptional.get();
        return modelMapper.map(reservation, ReservationDTO.class);
    }

    public ReservationDTO deleteReservation(Long id) {
        this.repository.deleteById(id);
        return ReservationDTO.builder().id(id).build();
    }

    public Page<ReservationDTO> getReservations(Pageable pageable) {
        Page<Reservation> reservations = this.repository.findAll(pageable);
        return reservations.map(this::to);
    }

    private ReservationDTO to(Reservation reservation) {
        return modelMapper.map(reservation, ReservationDTO.class);
    }
}
