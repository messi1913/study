package com.sf.cell2.account;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sf.cell2.common.Audit;
import com.sf.cell2.common.AuditListener;
import com.sf.cell2.common.Auditable;
import lombok.*;
import org.apache.catalina.Store;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Data
@Entity
@EqualsAndHashCode(of = "id")
@EntityListeners(AuditListener.class)
//@ToString(exclude = {"stores", "reservations"})
@Builder
@AllArgsConstructor @NoArgsConstructor
public class Account implements Auditable {

    @Embedded
    @JsonIgnore
    private Audit audit;

    @Id
    @GeneratedValue
    private long id;
    @NotNull
    @Column(nullable = false, unique = true)
    private String userName;
    private String password;
    @NotNull
    @Column(nullable = false, unique = true)
    private String email;
    private String mobileNumber;

    @ElementCollection(fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    private Set<AccountRole> roles;

//    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
//    private Set<Store> stores;
//
//    public void addStore(Store store) {
//        this.stores.add(store);
//        store.setOwner(this);
//    }
//
//    @OneToMany(mappedBy = "customer")
//    private Set<Reservation> reservations;
//
//    public void addReservation(Reservation reservation) {
//        this.reservations.add(reservation);
//        reservation.setCustomer(this);
//    }


}


