package com.sf.cell2.reservation;

public enum ReservationStatus {
    PRE_BOOKING, BOOKING, IN_PROGRESS, CANCELED, REJECTED, COMPLETED
}
